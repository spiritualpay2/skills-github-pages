---
title: "JSZip.version"
layout: default
section: api
---

The version of JSZip as a string.

__Since__: v3.1.0

## Example

```js
JSZip.version == "3.1.0";
```
